package com.example.tubes_cekpotensirisikojantung.ui.formCekRisiko;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tubes_cekpotensirisikojantung.R;

public class HasilActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);
    }
}
