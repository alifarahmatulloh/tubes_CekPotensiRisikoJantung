package com.example.tubes_cekpotensirisikojantung.ui.history;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tubes_cekpotensirisikojantung.R;

public class detail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
    }
}
