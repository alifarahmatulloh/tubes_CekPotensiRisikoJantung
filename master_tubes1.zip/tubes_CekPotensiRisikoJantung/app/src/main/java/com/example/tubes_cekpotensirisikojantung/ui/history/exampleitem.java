package com.example.tubes_cekpotensirisikojantung.ui.history;

public class exampleitem {
    private String mtext1;
    private String mtext2;
    private String mtext3;

    public exampleitem(String text1, String text2, String text3){
        mtext1 = text1;
        mtext2 = text2;
        mtext3 = text3;
    }

    public String getMtext1(){
        return mtext1;
    }

    public String getMtext2(){
        return mtext2;
    }

    public String getMtext3(){
        return mtext3;
    }

}
